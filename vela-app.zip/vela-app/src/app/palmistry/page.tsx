"use client";

import { useState } from "react";
import Link from "next/link";
import {
  generatePalmReading,
  type PalmInput,
  type PalmReading,
  type LineStrength,
  type HandShape,
} from "@/lib/palmistry/reading";

const lineOptions: { value: LineStrength; label: string }[] = [
  { value: "strong", label: "Strong & clear" },
  { value: "moderate", label: "Moderate" },
  { value: "weak", label: "Faint / weak" },
  { value: "broken", label: "Broken" },
  { value: "chained", label: "Chained / islanded" },
];

const fateOptions = [...lineOptions, { value: "absent" as const, label: "Absent" }];

export default function PalmistryPage() {
  const [input, setInput] = useState<PalmInput>({
    lifeLine: "moderate",
    heartLine: "moderate",
    headLine: "moderate",
    fateLine: "moderate",
    handShape: "earth",
    mounts: {
      jupiter: "developed",
      saturn: "flat",
      apollo: "developed",
      mercury: "flat",
      venus: "developed",
    },
  });
  const [reading, setReading] = useState<PalmReading | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setReading(generatePalmReading(input));
  };

  return (
    <main className="min-h-screen pb-16">
      <header className="px-6 py-5 flex items-center justify-between border-b border-ink/5 sticky top-0 bg-cream/90 backdrop-blur z-10">
        <Link href="/" className="flex items-center gap-3">
          <div className="w-7 h-7 rounded-full border-[1.5px] border-brass flex items-center justify-center">
            <div className="w-4 h-4 rounded-full border border-brass/60" />
          </div>
          <span className="font-serif text-lg">Vela</span>
        </Link>
        <span className="text-sm text-ink/50">Palmistry</span>
      </header>

      <div className="max-w-2xl mx-auto px-6 py-10">
        <h1 className="font-serif text-3xl mb-2">Palmistry</h1>
        <p className="text-ink/60 mb-8">
          Guided reading of major lines and mounts. Image upload can be added later.
        </p>

        {!reading ? (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm mb-1.5 text-ink/70">Hand Shape</label>
              <select
                value={input.handShape}
                onChange={(e) =>
                  setInput({ ...input, handShape: e.target.value as HandShape })
                }
                className="w-full px-4 py-3 rounded-xl bg-cream-dark/50 border border-ink/10 focus:outline-none focus:border-brass"
              >
                <option value="earth">Earth (square palm, short fingers)</option>
                <option value="air">Air (square palm, long fingers)</option>
                <option value="water">Water (long palm, long fingers)</option>
                <option value="fire">Fire (long palm, short fingers)</option>
              </select>
            </div>

            {(
              [
                ["lifeLine", "Life Line"],
                ["heartLine", "Heart Line"],
                ["headLine", "Head Line"],
              ] as const
            ).map(([key, label]) => (
              <div key={key}>
                <label className="block text-sm mb-1.5 text-ink/70">{label}</label>
                <select
                  value={input[key]}
                  onChange={(e) =>
                    setInput({ ...input, [key]: e.target.value as LineStrength })
                  }
                  className="w-full px-4 py-3 rounded-xl bg-cream-dark/50 border border-ink/10 focus:outline-none focus:border-brass"
                >
                  {lineOptions.map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
              </div>
            ))}

            <div>
              <label className="block text-sm mb-1.5 text-ink/70">Fate Line</label>
              <select
                value={input.fateLine}
                onChange={(e) =>
                  setInput({
                    ...input,
                    fateLine: e.target.value as LineStrength | "absent",
                  })
                }
                className="w-full px-4 py-3 rounded-xl bg-cream-dark/50 border border-ink/10 focus:outline-none focus:border-brass"
              >
                {fateOptions.map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </select>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-full bg-ink text-cream font-medium hover:bg-ink/90 transition-colors"
            >
              Generate Reading
            </button>
          </form>
        ) : (
          <div className="space-y-5">
            <div className="flex justify-end">
              <button
                onClick={() => setReading(null)}
                className="text-sm px-4 py-2 rounded-full border border-ink/15 hover:border-brass transition-colors"
              >
                New Reading
              </button>
            </div>

            <div className="p-5 rounded-2xl bg-cream-dark/40 border border-ink/5">
              <p className="text-sm leading-relaxed text-ink/80">{reading.summary}</p>
            </div>

            {[
              { title: "Life Line", text: reading.lifeLine },
              { title: "Heart Line", text: reading.heartLine },
              { title: "Head Line", text: reading.headLine },
              { title: "Fate Line", text: reading.fateLine },
              { title: "Hand Shape", text: reading.handShape },
              { title: "Mounts", text: reading.mounts },
            ].map((item) => (
              <div
                key={item.title}
                className="p-5 rounded-2xl bg-cream-dark/30 border border-ink/5"
              >
                <h3 className="font-serif text-lg mb-1.5">{item.title}</h3>
                <p className="text-sm text-ink/70 leading-relaxed">{item.text}</p>
              </div>
            ))}

            <div className="p-5 rounded-2xl border border-brass/30 bg-brass/5">
              <h3 className="font-serif text-lg mb-1.5">Overall</h3>
              <p className="text-sm text-ink/70 leading-relaxed">{reading.overall}</p>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
