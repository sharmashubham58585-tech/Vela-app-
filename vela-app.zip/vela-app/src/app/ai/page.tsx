"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { getFreeQuestions, useOneQuestion } from "@/lib/free-questions";

export default function AIAstrologerPage() {
  const [question, setQuestion] = useState("");
  const [messages, setMessages] = useState<
    { role: "user" | "assistant"; content: string }[]
  >([]);
  const [free, setFree] = useState({ used: 0, remaining: 3, max: 3 });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setFree(getFreeQuestions());
  }, []);

  const handleAsk = async () => {
    if (!question.trim()) return;
    if (free.remaining <= 0) {
      alert("You have used all 3 free questions. Upgrade to continue.");
      return;
    }

    const userMsg = question.trim();
    setMessages((prev) => [...prev, { role: "user", content: userMsg }]);
    setQuestion("");
    setLoading(true);

    // Consume one free question
    const updated = useOneQuestion();
    setFree(updated);

    // Simulate AI response (replace with real API call later)
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content:
            "This is a placeholder response. In the full version, the AI will receive your actual natal chart data (planets, dasha, transits) and give a calm, chart-grounded answer.\n\nTo complete this: connect OpenAI / Grok / Claude API and pass the calculated ChartData as context.",
        },
      ]);
      setLoading(false);
    }, 1200);
  };

  return (
    <main className="min-h-screen flex flex-col">
      <header className="px-6 py-5 flex items-center justify-between border-b border-ink/5">
        <Link href="/" className="flex items-center gap-3">
          <div className="w-7 h-7 rounded-full border-[1.5px] border-brass flex items-center justify-center">
            <div className="w-4 h-4 rounded-full border border-brass/60" />
          </div>
          <span className="font-serif text-lg">Vela</span>
        </Link>
        <div className="text-sm">
          <span className="text-ink/50">Free questions left: </span>
          <span className="font-medium text-brass">{free.remaining}</span>
        </div>
      </header>

      <div className="flex-1 max-w-2xl mx-auto w-full px-6 py-8 flex flex-col">
        <h1 className="font-serif text-2xl mb-1">AI Astrologer</h1>
        <p className="text-ink/60 text-sm mb-6">
          Ask anything about your chart. Answers stay calm and observational.
        </p>

        {/* Messages */}
        <div className="flex-1 space-y-4 mb-6 overflow-y-auto min-h-[300px]">
          {messages.length === 0 && (
            <div className="text-center text-ink/40 py-12 text-sm">
              Your conversation will appear here.
              <br />
              Example: “What does my current dasha suggest for career?”
            </div>
          )}
          {messages.map((m, i) => (
            <div
              key={i}
              className={`p-4 rounded-2xl text-sm leading-relaxed ${
                m.role === "user"
                  ? "bg-ink text-cream ml-8"
                  : "bg-cream-dark/60 border border-ink/5 mr-8"
              }`}
            >
              {m.content}
            </div>
          ))}
          {loading && (
            <div className="text-ink/40 text-sm italic">Observing the chart…</div>
          )}
        </div>

        {/* Input */}
        <div className="border-t border-ink/5 pt-4">
          {free.remaining <= 0 ? (
            <div className="text-center p-4 rounded-xl bg-cream-dark/50 text-sm">
              <p className="mb-2">You have used all 3 free questions.</p>
              <button className="px-5 py-2 rounded-full bg-ink text-cream text-sm">
                Upgrade for unlimited access
              </button>
            </div>
          ) : (
            <div className="flex gap-3">
              <input
                type="text"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleAsk()}
                placeholder="Ask about your chart…"
                className="flex-1 px-4 py-3 rounded-xl bg-cream-dark/50 border border-ink/10 focus:outline-none focus:border-brass transition-colors text-sm"
              />
              <button
                onClick={handleAsk}
                disabled={loading || !question.trim()}
                className="px-5 py-3 rounded-xl bg-ink text-cream text-sm font-medium disabled:opacity-40 hover:bg-ink/90 transition-colors"
              >
                Ask
              </button>
            </div>
          )}
        </div>
      </div>
    </main>
  );
}
