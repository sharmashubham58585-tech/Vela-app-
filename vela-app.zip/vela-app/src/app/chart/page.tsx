"use client";

import { useState } from "react";
import Link from "next/link";
import { generateMockChart } from "@/lib/astrology/mock-chart";
import type { ChartData, BirthData } from "@/types/astrology";

export default function ChartPage() {
  const [form, setForm] = useState({
    name: "",
    date: "",
    time: "12:00",
    place: "",
    latitude: "23.2599",
    longitude: "77.4126",
  });
  const [chart, setChart] = useState<ChartData | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    setTimeout(() => {
      const birth: BirthData = {
        name: form.name || undefined,
        date: form.date,
        time: form.time,
        place: form.place,
        latitude: parseFloat(form.latitude) || 23.26,
        longitude: parseFloat(form.longitude) || 77.41,
        timezone: "Asia/Kolkata",
      };
      const result = generateMockChart(birth);
      setChart(result);
      setLoading(false);
    }, 800);
  };

  return (
    <main className="min-h-screen pb-16">
      <header className="px-6 py-5 flex items-center justify-between border-b border-ink/5 sticky top-0 bg-cream/90 backdrop-blur z-10">
        <Link href="/" className="flex items-center gap-3">
          <div className="w-7 h-7 rounded-full border-[1.5px] border-brass flex items-center justify-center">
            <div className="w-4 h-4 rounded-full border border-brass/60" />
          </div>
          <span className="font-serif text-lg">Vela</span>
        </Link>
        <span className="text-sm text-ink/50">Natal Chart</span>
      </header>

      <div className="max-w-3xl mx-auto px-6 py-10">
        {!chart ? (
          <>
            <h1 className="font-serif text-3xl mb-2">Generate your chart</h1>
            <p className="text-ink/60 mb-8">
              Enter accurate birth details. Demo uses mock calculations — replace with Swiss Ephemeris for production accuracy.
            </p>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="block text-sm mb-1.5 text-ink/70">Name (optional)</label>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-cream-dark/50 border border-ink/10 focus:outline-none focus:border-brass transition-colors"
                  placeholder="Your name"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm mb-1.5 text-ink/70">Date of Birth</label>
                  <input
                    type="date"
                    required
                    value={form.date}
                    onChange={(e) => setForm({ ...form, date: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-cream-dark/50 border border-ink/10 focus:outline-none focus:border-brass transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-sm mb-1.5 text-ink/70">Time of Birth</label>
                  <input
                    type="time"
                    required
                    value={form.time}
                    onChange={(e) => setForm({ ...form, time: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-cream-dark/50 border border-ink/10 focus:outline-none focus:border-brass transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm mb-1.5 text-ink/70">Place of Birth</label>
                <input
                  type="text"
                  required
                  value={form.place}
                  onChange={(e) => setForm({ ...form, place: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-cream-dark/50 border border-ink/10 focus:outline-none focus:border-brass transition-colors"
                  placeholder="City, Country"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm mb-1.5 text-ink/70">Latitude</label>
                  <input
                    type="text"
                    value={form.latitude}
                    onChange={(e) => setForm({ ...form, latitude: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-cream-dark/50 border border-ink/10 focus:outline-none focus:border-brass transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-sm mb-1.5 text-ink/70">Longitude</label>
                  <input
                    type="text"
                    value={form.longitude}
                    onChange={(e) => setForm({ ...form, longitude: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-cream-dark/50 border border-ink/10 focus:outline-none focus:border-brass transition-colors"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 rounded-full bg-ink text-cream font-medium hover:bg-ink/90 transition-colors mt-2 disabled:opacity-50"
              >
                {loading ? "Calculating…" : "Calculate Chart"}
              </button>
            </form>
          </>
        ) : (
          <div className="space-y-8">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h1 className="font-serif text-3xl mb-1">
                  {chart.birth.name || "Your"} Chart
                </h1>
                <p className="text-ink/60 text-sm">
                  {chart.birth.date} · {chart.birth.time} · {chart.birth.place}
                </p>
              </div>
              <button
                onClick={() => setChart(null)}
                className="text-sm px-4 py-2 rounded-full border border-ink/15 hover:border-brass transition-colors"
              >
                New Chart
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-5 rounded-2xl bg-cream-dark/40 border border-ink/5">
                <p className="text-xs uppercase tracking-wider text-ink/40 mb-1">Lagna (Ascendant)</p>
                <p className="font-serif text-xl">
                  {chart.lagna.sign} {chart.lagna.degree}°
                </p>
              </div>
              {chart.currentDasha && (
                <div className="p-5 rounded-2xl bg-cream-dark/40 border border-ink/5">
                  <p className="text-xs uppercase tracking-wider text-ink/40 mb-1">Current Dasha</p>
                  <p className="font-serif text-xl">
                    {chart.currentDasha.mahadasha} – {chart.currentDasha.antardasha}
                  </p>
                  <p className="text-xs text-ink/50 mt-1">
                    until {chart.currentDasha.endDate}
                  </p>
                </div>
              )}
            </div>

            <div>
              <h2 className="font-serif text-xl mb-4">Planetary Positions</h2>
              <div className="overflow-x-auto rounded-2xl border border-ink/5">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-cream-dark/60 text-left text-ink/50">
                      <th className="px-4 py-3 font-medium">Planet</th>
                      <th className="px-4 py-3 font-medium">Sign</th>
                      <th className="px-4 py-3 font-medium">Degree</th>
                      <th className="px-4 py-3 font-medium">Nakshatra</th>
                      <th className="px-4 py-3 font-medium">House</th>
                      <th className="px-4 py-3 font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {chart.planets.map((p) => (
                      <tr key={p.name} className="border-t border-ink/5">
                        <td className="px-4 py-3 font-medium">{p.name}</td>
                        <td className="px-4 py-3">{p.sign}</td>
                        <td className="px-4 py-3">{p.signDegree}°</td>
                        <td className="px-4 py-3">
                          {p.nakshatra} (Pada {p.pada})
                        </td>
                        <td className="px-4 py-3">{p.house}</td>
                        <td className="px-4 py-3">
                          {p.isRetrograde ? (
                            <span className="text-brass text-xs">Retrograde</span>
                          ) : (
                            <span className="text-ink/30 text-xs">—</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div>
              <h2 className="font-serif text-xl mb-4">Houses</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {chart.houses.map((h) => (
                  <div
                    key={h.number}
                    className="p-3 rounded-xl bg-cream-dark/30 border border-ink/5 text-center"
                  >
                    <p className="text-xs text-ink/40">House {h.number}</p>
                    <p className="font-medium text-sm mt-0.5">
                      {h.sign} {h.degree}°
                    </p>
                  </div>
                ))}
              </div>
            </div>

            <p className="text-xs text-ink/40 text-center pt-4">
              Demo calculation. For production accuracy integrate Swiss Ephemeris or a certified Vedic library.
            </p>
          </div>
        )}
      </div>
    </main>
  );
}
