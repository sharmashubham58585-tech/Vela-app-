"use client";

import { useState } from "react";
import Link from "next/link";
import { calculateNumerology, type NumerologyResult } from "@/lib/numerology/calculate";

export default function NumerologyPage() {
  const [name, setName] = useState("");
  const [dob, setDob] = useState("");
  const [result, setResult] = useState<NumerologyResult | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !dob) return;
    const res = calculateNumerology(name.trim(), dob);
    setResult(res);
  };

  return (
    <main className="min-h-screen pb-16">
      <header className="px-6 py-5 flex items-center justify-between border-b border-ink/5 sticky top-0 bg-cream/90 backdrop-blur z-10">
        <Link href="/" className="flex items-center gap-3">
          <div className="w-7 h-7 rounded-full border-[1.5px] border-brass flex items-center justify-center">
            <div className="w-4 h-4 rounded-full border border-brass/60" />
          </div>
          <span className="font-serif text-lg">Vela</span>
        </Link>
        <span className="text-sm text-ink/50">Numerology</span>
      </header>

      <div className="max-w-2xl mx-auto px-6 py-10">
        <h1 className="font-serif text-3xl mb-2">Numerology</h1>
        <p className="text-ink/60 mb-8">
          Discover your Life Path, Destiny, Soul Urge and Personality numbers.
        </p>

        {!result ? (
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm mb-1.5 text-ink/70">Full Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-cream-dark/50 border border-ink/10 focus:outline-none focus:border-brass transition-colors"
                placeholder="As on official documents"
              />
            </div>
            <div>
              <label className="block text-sm mb-1.5 text-ink/70">Date of Birth</label>
              <input
                type="date"
                required
                value={dob}
                onChange={(e) => setDob(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-cream-dark/50 border border-ink/10 focus:outline-none focus:border-brass transition-colors"
              />
            </div>
            <button
              type="submit"
              className="w-full py-3.5 rounded-full bg-ink text-cream font-medium hover:bg-ink/90 transition-colors"
            >
              Calculate Numbers
            </button>
          </form>
        ) : (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <p className="text-ink/60 text-sm">{name} · {dob}</p>
              <button
                onClick={() => setResult(null)}
                className="text-sm px-4 py-2 rounded-full border border-ink/15 hover:border-brass transition-colors"
              >
                New Reading
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { label: "Life Path", value: result.lifePath },
                { label: "Destiny", value: result.destiny },
                { label: "Soul Urge", value: result.soulUrge },
                { label: "Personality", value: result.personality },
              ].map((item) => (
                <div
                  key={item.label}
                  className="p-4 rounded-2xl bg-cream-dark/40 border border-ink/5 text-center"
                >
                  <p className="text-xs text-ink/40 uppercase tracking-wider">{item.label}</p>
                  <p className="font-serif text-3xl mt-1 text-ink">{item.value}</p>
                </div>
              ))}
            </div>

            <div className="space-y-4">
              <div className="p-5 rounded-2xl bg-cream-dark/30 border border-ink/5">
                <h3 className="font-serif text-lg mb-2">Life Path {result.lifePath}</h3>
                <p className="text-sm text-ink/70 leading-relaxed">{result.interpretations.lifePath}</p>
              </div>
              <div className="p-5 rounded-2xl bg-cream-dark/30 border border-ink/5">
                <h3 className="font-serif text-lg mb-2">Destiny {result.destiny}</h3>
                <p className="text-sm text-ink/70 leading-relaxed">{result.interpretations.destiny}</p>
              </div>
              <div className="p-5 rounded-2xl bg-cream-dark/30 border border-ink/5">
                <h3 className="font-serif text-lg mb-2">Soul Urge {result.soulUrge}</h3>
                <p className="text-sm text-ink/70 leading-relaxed">{result.interpretations.soulUrge}</p>
              </div>
              <div className="p-5 rounded-2xl bg-cream-dark/30 border border-ink/5">
                <h3 className="font-serif text-lg mb-2">Personality {result.personality}</h3>
                <p className="text-sm text-ink/70 leading-relaxed">{result.interpretations.personality}</p>
              </div>
            </div>

            <div className="p-5 rounded-2xl border border-brass/30 bg-brass/5">
              <p className="text-sm text-ink/70">
                <span className="font-medium text-ink">Lucky numbers:</span>{" "}
                {result.luckyNumbers.join(", ")}
              </p>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
