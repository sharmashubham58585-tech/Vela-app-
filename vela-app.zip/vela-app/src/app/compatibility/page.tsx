"use client";

import { useState } from "react";
import Link from "next/link";
import {
  calculateCompatibility,
  type CompatibilityResult,
} from "@/lib/astrology/compatibility";

export default function CompatibilityPage() {
  const [boy, setBoy] = useState({ name: "", date: "" });
  const [girl, setGirl] = useState({ name: "", date: "" });
  const [result, setResult] = useState<CompatibilityResult | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!boy.name || !boy.date || !girl.name || !girl.date) return;
    const res = calculateCompatibility(boy.name, boy.date, girl.name, girl.date);
    setResult(res);
  };

  return (
    <main className="min-h-screen pb-16">
      <header className="px-6 py-5 flex items-center justify-between border-b border-ink/5 sticky top-0 bg-cream/90 backdrop-blur z-10">
        <Link href="/" className="flex items-center gap-3">
          <div className="w-7 h-7 rounded-full border-[1.5px] border-brass flex items-center justify-center">
            <div className="w-4 h-4 rounded-full border border-brass/60" />
          </div>
          <span className="font-serif text-lg">Vela</span>
        </Link>
        <span className="text-sm text-ink/50">Compatibility</span>
      </header>

      <div className="max-w-2xl mx-auto px-6 py-10">
        <h1 className="font-serif text-3xl mb-2">Kundali Milan</h1>
        <p className="text-ink/60 mb-8">
          Ashtakoot matching (36 points) with Manglik analysis.
        </p>

        {!result ? (
          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="space-y-4">
              <h2 className="font-serif text-lg text-ink/80">Partner 1</h2>
              <div>
                <label className="block text-sm mb-1.5 text-ink/70">Name</label>
                <input
                  type="text"
                  required
                  value={boy.name}
                  onChange={(e) => setBoy({ ...boy, name: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-cream-dark/50 border border-ink/10 focus:outline-none focus:border-brass"
                />
              </div>
              <div>
                <label className="block text-sm mb-1.5 text-ink/70">Date of Birth</label>
                <input
                  type="date"
                  required
                  value={boy.date}
                  onChange={(e) => setBoy({ ...boy, date: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-cream-dark/50 border border-ink/10 focus:outline-none focus:border-brass"
                />
              </div>
            </div>

            <div className="space-y-4">
              <h2 className="font-serif text-lg text-ink/80">Partner 2</h2>
              <div>
                <label className="block text-sm mb-1.5 text-ink/70">Name</label>
                <input
                  type="text"
                  required
                  value={girl.name}
                  onChange={(e) => setGirl({ ...girl, name: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-cream-dark/50 border border-ink/10 focus:outline-none focus:border-brass"
                />
              </div>
              <div>
                <label className="block text-sm mb-1.5 text-ink/70">Date of Birth</label>
                <input
                  type="date"
                  required
                  value={girl.date}
                  onChange={(e) => setGirl({ ...girl, date: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-cream-dark/50 border border-ink/10 focus:outline-none focus:border-brass"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-full bg-ink text-cream font-medium hover:bg-ink/90 transition-colors"
            >
              Calculate Match
            </button>
          </form>
        ) : (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <p className="text-sm text-ink/60">
                {boy.name} & {girl.name}
              </p>
              <button
                onClick={() => setResult(null)}
                className="text-sm px-4 py-2 rounded-full border border-ink/15 hover:border-brass transition-colors"
              >
                New Match
              </button>
            </div>

            {/* Score */}
            <div className="p-6 rounded-2xl bg-cream-dark/40 border border-ink/5 text-center">
              <p className="text-xs uppercase tracking-wider text-ink/40 mb-1">
                Guna Milan Score
              </p>
              <p className="font-serif text-5xl text-ink">
                {result.totalScore}
                <span className="text-2xl text-ink/40"> / 36</span>
              </p>
              <p className="text-brass mt-1 font-medium">{result.percentage}%</p>
              <p className="text-sm text-ink/70 mt-3 max-w-md mx-auto">
                {result.overall}
              </p>
            </div>

            {/* Gunas breakdown */}
            <div>
              <h3 className="font-serif text-lg mb-3">Guna Breakdown</h3>
              <div className="space-y-2">
                {result.gunas.map((g) => (
                  <div
                    key={g.name}
                    className="flex items-center justify-between p-3 rounded-xl bg-cream-dark/30 border border-ink/5"
                  >
                    <div>
                      <p className="text-sm font-medium">{g.name}</p>
                      <p className="text-xs text-ink/50">{g.meaning}</p>
                    </div>
                    <p className="font-serif text-lg">
                      {g.score}
                      <span className="text-sm text-ink/40">/{g.max}</span>
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Manglik */}
            <div className="p-5 rounded-2xl border border-ink/10">
              <h3 className="font-serif text-lg mb-2">Manglik Analysis</h3>
              <p className="text-sm text-ink/70">{result.manglik.status}</p>
            </div>

            {/* Strengths & Challenges */}
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="p-5 rounded-2xl bg-cream-dark/30 border border-ink/5">
                <h3 className="font-serif text-base mb-2">Strengths</h3>
                <ul className="text-sm text-ink/70 space-y-1">
                  {result.strengths.map((s) => (
                    <li key={s}>• {s}</li>
                  ))}
                </ul>
              </div>
              <div className="p-5 rounded-2xl bg-cream-dark/30 border border-ink/5">
                <h3 className="font-serif text-base mb-2">Areas to watch</h3>
                <ul className="text-sm text-ink/70 space-y-1">
                  {result.challenges.map((c) => (
                    <li key={c}>• {c}</li>
                  ))}
                </ul>
              </div>
            </div>

            <p className="text-xs text-ink/40 text-center">
              Demo matching. Production version should use actual natal charts + full Ashtakoot rules.
            </p>
          </div>
        )}
      </div>
    </main>
  );
}
